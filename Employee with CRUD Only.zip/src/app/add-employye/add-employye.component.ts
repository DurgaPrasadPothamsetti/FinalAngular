import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employye',
  templateUrl: './add-employye.component.html',
  styleUrls: ['./add-employye.component.css']
})

export class AddEmployyeComponent implements OnInit {

  bookList: any = [];
  book: Employee = new Employee();

  constructor(private bookService: EmployeeService) {
    this.bookService.getEmployeeDetails().subscribe(data => this.bookList = data);
  }

  ngOnInit() {
  }

  genre: string[] = ["IT", "CSE", "ECE", "EEE", "CIVIL"];
  imgsrc: string = "./assets/images.jpg";
  imgsrc1: string = "./assets/girl.jpg";


  insertEmployee(data) {
    alert(`Code: ${data.code} Name: ${data.name} Author: ${data.author} Genre: ${data.genre}`);
    this.book.code = data.code;
    this.book.name = data.name;
    this.book.author = data.author;
    this.book.genre = data.genre;
    console.log(this.book);
    this.bookService.setBookDetails(this.book);
  }
  show(data): void {
    alert(`Employee Added\nId: ${data.code} Name: ${data.name} Author: ${data.author} Genre: ${data.genre}`);
  }
  onClickSubmit(d) {
    alert("Entered Email id : " + d.emailid);
  }
}
