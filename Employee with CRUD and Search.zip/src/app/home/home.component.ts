import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})


export class HomeComponent implements OnInit {

  bookList:any=[];
  constructor(private bookService:EmployeeService) { 
  this.bookList= this.bookService.bookList;
   
  }
  
  ngOnInit() {
    this.bookList= this.bookService.bookList;
    
  }
  reload(){
    this.bookList= this.bookService.bookList;
  }

  flag=false;
name;code;author;genre;

bo:Employee=new Employee;
  changeFlag(b:Employee){
    this.flag=true;
    this.name=b.name;this.code=b.code;this.author=b.author;this.genre=b.genre;
    

  }
  update
  (f){
   let b:Employee=new Employee;
  b=f;
  console.log(b);
  this.bookService.updateBookDetails(b);
  }

  delete(code:number){
    this.bookService.deleteBook(code);
    this.bookList= this.bookService.bookList;
  }
}

