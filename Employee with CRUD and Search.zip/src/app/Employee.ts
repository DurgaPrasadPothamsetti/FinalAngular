export class Employee{
    code:number;
    name:string;
    author:string;
    genre:string;
    }